setwd('C:\\Users\\asus\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24100084')
## Q1(a) & (b)
n <- 50
p <- 0.85

1 - pbinom(46, n, p)

## Q2

lambda <- 12

dpois(15, lambda)

